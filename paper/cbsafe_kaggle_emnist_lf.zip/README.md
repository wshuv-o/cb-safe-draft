# CB-SAFE on Kaggle - EMNIST label-flip (30 rounds, all methods)

Runs the **EMNIST half of the label-flip sweep** (the CIFAR-10 + FashionMNIST half
runs locally). All 12 methods x 3 malicious fractions x 1 seed = **36 runs** at
**30 rounds** (matched to the local EMNIST runs). EMNIST auto-downloads via
torchvision, so **no dataset needs to be added**.

## Steps
1. Upload this zip as a Kaggle Dataset (New Dataset -> upload -> Create).
2. Settings -> Accelerator = **GPU T4**, Internet = **On**. (Use T4, not P100.)
3. Run one cell:
   ```python
   import glob, subprocess, sys
   run = glob.glob('/kaggle/input/**/run_emnist_lf_kaggle.py', recursive=True)[0]
   subprocess.run([sys.executable, run], check=True)
   ```
4. When it prints `ALL-KAGGLE COMPLETE`, package + download:
   ```python
   import shutil
   shutil.make_archive('/kaggle/working/cbsafe_lf_results', 'zip', '/kaggle/working/results')
   ```
   Download `cbsafe_lf_results.zip` and send it back.

## Notes
- Resumable: finished CSVs are skipped; re-run the cell to continue.
- ~36 runs, EMNIST-sized; one T4 session is plenty (~2-3 h).
- Results land in `/kaggle/working/results/kaggle/emnist/robust_labelflip_*.csv`.
