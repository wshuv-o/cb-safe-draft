# CB-SAFE on Kaggle — Edge-IIoTset only, all methods

This bundle runs **every method on Edge-IIoTset** (the one dataset whose source
CSV is Kaggle-hosted). The three image datasets (CIFAR-10, FashionMNIST, EMNIST)
are being run locally, so Kaggle only has to do its fair share -> **~144 runs,
tabular and fast (~2-3 min each) -> one T4 session (~5-7 h).**

Methods compared (all our own faithful implementations of the published
algorithms, each cited in the paper, run under ONE shared harness = a controlled
comparison):

- **Baselines:** FedAvg mean, trimmed mean, median, Multi-Krum [NeurIPS'17],
  Bulyan [ICML'18], geometric-median / RFA, FLTrust [NDSS'21], FedGT [TIFS'25].
- **Ours:** CB-SAFE+ (reputation), CB-SAFE+ ov4, trust-free, hybrid (temporal
  group testing).

Attacks: sign-flip (3 seeds, the headline) and label-flip (1 seed).

---

## Steps

1. **Upload this zip as a Kaggle Dataset** (New Dataset -> upload -> Create).
2. **Add the Edge-IIoTset dataset:** *Add Data* -> search **"Edge-IIoTset"** -> add
   the one containing `DNN-EdgeIIoT-dataset.csv`
   (`mohamedamineferrag/edgeiiotset-cyber-security-dataset-of-iot-iiot`).
3. **Settings -> Accelerator = GPU T4**, Internet = **On**.
   *(Use T4, NOT P100 - Kaggle's current PyTorch has no P100 kernels.)*
4. **Run one cell:**
   ```python
   import glob, subprocess, sys
   run = glob.glob('/kaggle/input/**/run_edge_kaggle.py', recursive=True)[0]
   subprocess.run([sys.executable, run], check=True)
   ```
5. **Download results** when it prints `ALL-KAGGLE COMPLETE` (or before the session
   hits 12h):
   ```python
   import shutil; shutil.make_archive('/kaggle/working/cbsafe_results', 'zip',
                                       '/kaggle/working/results')
   ```
   Download `cbsafe_results.zip` and send it back.

---

## Important notes

- **Resumable.** Every finished run is one CSV and is skipped on re-run. If a
  session ends early, just re-run the same cell in a new session and it continues.
  One session should be enough for Edge-IIoTset, but this is the safety net.
- **This bundle is Edge-only by design.** `run_edge_kaggle.py` sets
  `CBSAFE_DATASETS=edgeiiot`. (The full runner `run_all_kaggle.py` is also in the
  bundle if you ever want all four datasets: run it instead - but that is
  ~60-70 GPU-hours and will span several sessions.)
- **GPU compatibility:** if you see `no kernel image is available`, that is the
  P100 again - switch the accelerator to **T4** and restart.
- **CPU fallback:** Edge-IIoTset is tabular, so even with `CUDA_VISIBLE_DEVICES=""`
  it runs fine, just a bit slower.
- No liboqs / crypto build needed - this is pure PyTorch (masking correctness is
  proven separately and is dataset-independent).
